##############################################################################
# main                                                                       #
##############################################################################

# Dans ce fichier que vous pouvez compléter vous lancez vos expérimentations

from moteur_diamant import partie_diamant


if __name__ == '__main__':
    partie_diamant(5,['IA_Picsou', 'IA_aleatoire','IA_temeraire', 'IA_trouillarde'])